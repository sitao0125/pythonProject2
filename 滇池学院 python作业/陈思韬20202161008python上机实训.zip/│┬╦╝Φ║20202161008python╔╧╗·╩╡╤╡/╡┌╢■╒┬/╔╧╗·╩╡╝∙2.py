# 2020级人工智能一班
# 陈思韬
# 开发时间: 2022/4/15 11:25
import math
r=float(input("请输入球的半径"))
s=4*(math.pi)*r*r

print("球的表面积为：",'%.2f'%s)


v=3*math.pi*(r**3)/4
print("球的体积为：",'%.2f'%v)

