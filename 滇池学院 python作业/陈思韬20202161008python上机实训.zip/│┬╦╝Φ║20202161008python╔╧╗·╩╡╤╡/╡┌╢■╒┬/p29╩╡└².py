# 2020级人工智能一班
# 陈思韬
# 开发时间: 2022/4/15 11:01
import random
red =random.sample(range(1,34),6)
blue=random.choice(range(1,17))
print("本期双色球开出的号码：")
print("红球：",red)
print("蓝球",blue)