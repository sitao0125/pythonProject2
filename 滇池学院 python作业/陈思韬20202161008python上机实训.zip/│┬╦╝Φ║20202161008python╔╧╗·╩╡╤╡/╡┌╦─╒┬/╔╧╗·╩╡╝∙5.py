# 2020级人工智能一班
# 陈思韬
# 开发时间: 2022/4/28 21:47
def mi():
    x=int(input("请输入一个数作为底数"))
    n=int(input("请输入一个数作为幂"))
    num=pow(x,n)
    print("计算结果为：",num)

mi()