# 2020级人工智能一班
# 陈思韬
# 开发时间: 2022/4/28 21:54
def order_by():
    str1=input("请输入一段数字")
    return str1[::-1]


print(order_by())

